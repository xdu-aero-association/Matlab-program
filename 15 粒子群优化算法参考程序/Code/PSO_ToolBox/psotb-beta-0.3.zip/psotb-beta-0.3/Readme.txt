NOTE: THIS IS AN ALPHA RELEASE. FOR TESTING ONLY.

1. Installation:
	-Unzip and copy the files to a folder (directory).
	-Add the path to Matlab. (File>Set Path>Add with Subfolders)
	-Read help for get_psoOptions.m and pso.m (enter help get_psoOptions at command line)
	-Run PSO for u'r system.

	PLEASE CHECK http://psotoolbox.sourceforge.net FOR UPDATES

	